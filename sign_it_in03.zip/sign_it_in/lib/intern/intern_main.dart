import 'dart:html';
import 'package:flutter/material.dart';
import 'package:sign_it_in/nav.dart';
import 'package:sign_it_in/home_screen.dart';
import 'package:sign_it_in/intern/intern_slider_bar.dart';
import 'package:sign_it_in/intern/intern_homescreen.dart';
import 'package:sign_it_in/intern/intern_checkbox.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

bool show = true;
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  show = prefs.getBool('ON_BOARDING') ?? true;
  runApp(Intern_MyApp());
}

class Intern_MyApp extends StatelessWidget {
  const Intern_MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: show ? Intern_IntroScreen() : const Intern_HomeScreen(),
    );
  }
}

class Intern_IntroScreen extends StatelessWidget {
  Intern_IntroScreen({Key? key}) : super(key: key);

  ///Changed a little bit of buttons styling and text for the thumbnail lol
  ///Thanks for coming here :-)
  final List<PageViewModel> pages = [
    PageViewModel(
        decoration: const PageDecoration(
            pageColor: Color.fromARGB(255, 34, 34, 34),
            titleTextStyle: TextStyle(
              fontSize: 25.0,
              fontWeight: FontWeight.bold,
            )),
        title: 'Please Choose An Option',
        body: 'Would you like to...',
        footer: SizedBox(
            height: 800,
            width: 400,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  FlatButton(
                    minWidth: 300.0,
                    height: 70.0,
                    onPressed: () => {},
                    color: Colors.red,
                    padding: EdgeInsets.all(10.0),
                    child: Column(
                      // Replace with a Row for horizontal icon + text
                      children: <Widget>[
                        //Image.asset('images/img_intern1a1.png'),
                        Text("Setup Accout")
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  FlatButton(
                    minWidth: 300.0,
                    height: 70.0,
                    onPressed: () => {},
                    color: Colors.grey,
                    padding: EdgeInsets.all(10.0),
                    child: Column(
                      // Replace with a Row for horizontal icon + text
                      children: <Widget>[
                        //Image.asset('images/img_intern1a1.png'),
                        Text("Continue Anonymously")
                      ],
                    ),
                  ),
                ]))),
    PageViewModel(
        decoration: const PageDecoration(
            pageColor: Color.fromARGB(255, 34, 34, 34),
            titleTextStyle: TextStyle(
              fontSize: 25.0,
              fontWeight: FontWeight.bold,
            )),
        title: 'Basic Account Details',
        body: 'Please fill in the following',
        footer: SizedBox(
            child: Column(children: [
          Container(
              height: 50,
              width: 300,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(10)),
              child: Container(
                width: 250,
                child: TextField(
                  decoration: InputDecoration(
                    labelText: 'Email Address',
                    suffixIcon: Icon(
                      Icons.mail,
                      size: 20,
                    ),
                  ),
                ),
              )),
          SizedBox(height: 30),
          Container(
              height: 50,
              width: 300,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(10)),
              child: Container(
                width: 250,
                child: TextField(
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Passwords',
                    suffixIcon: Icon(
                      Icons.key,
                      size: 20,
                    ),
                  ),
                ),
              )),
          SizedBox(height: 30),
          Container(
              height: 50,
              width: 300,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(10)),
              child: Container(
                width: 250,
                child: TextField(
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Confirm Password',
                    suffixIcon: Icon(
                      Icons.key,
                      size: 20,
                    ),
                  ),
                ),
              )),
          SizedBox(height: 30),
          FlatButton(
            minWidth: 300.0,
            height: 70.0,
            onPressed: () => {},
            color: Colors.red,
            padding: EdgeInsets.all(10.0),
            child: Column(
              // Replace with a Row for horizontal icon + text
              children: <Widget>[
                //Image.asset('images/img_intern1a1.png'),
                Text("Setup Accout")
              ],
            ),
          ),
        ]))),
    PageViewModel(
        decoration: const PageDecoration(
            pageColor: Color.fromARGB(255, 34, 34, 34),
            titleTextStyle: TextStyle(
              fontSize: 25.0,
              fontWeight: FontWeight.bold,
            )),
        title: 'Personal',
        body: 'Please fill in the following',
        footer: SizedBox(
            child: Column(children: [
          Container(
              height: 50,
              width: 300,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(10)),
              child: Container(
                width: 250,
                child: TextField(
                  decoration: InputDecoration(
                    labelText: 'First Name',
                    suffixIcon: Icon(
                      Icons.person,
                      size: 20,
                    ),
                  ),
                ),
              )),
          SizedBox(height: 30),
          Container(
              height: 50,
              width: 300,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(10)),
              child: Container(
                width: 250,
                child: TextField(
                  decoration: InputDecoration(
                    labelText: 'Last Name',
                    suffixIcon: Icon(
                      Icons.person,
                      size: 20,
                    ),
                  ),
                ),
              )),
          SizedBox(height: 30),
          Container(
              height: 350,
              width: 300,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(10)),
              child: Container(
                width: 250,
                height: 300,
                child: TextField(
                  decoration: InputDecoration(
                    labelText: 'Basic internship description',
                    suffixIcon: Icon(
                      Icons.comment,
                      size: 20,
                    ),
                  ),
                ),
              )),
          SizedBox(height: 30),
          FlatButton(
            minWidth: 300.0,
            height: 70.0,
            onPressed: () => {},
            color: Colors.red,
            padding: EdgeInsets.all(10.0),
            child: Column(
              // Replace with a Row for horizontal icon + text
              children: <Widget>[
                //Image.asset('images/img_intern1a1.png'),
                Text("Next")
              ],
            ),
          )
        ]))),
    PageViewModel(
        decoration: const PageDecoration(
            pageColor: Color.fromARGB(255, 34, 34, 34),
            titleTextStyle: TextStyle(
              fontSize: 25.0,
              fontWeight: FontWeight.bold,
            )),
        title: 'What are you experienced in ?',
        body: 'Please select from the following',
        image: Center(
          child: Image.asset('images/img_sideways.png'),
        ),
        footer: Column(
          children: [
            SizedBox(
              height: 510,
              child: Intern_CheckBoxes(),
            ),
            FlatButton(
              minWidth: 300.0,
              height: 70.0,
              onPressed: () => {},
              color: Colors.red,
              padding: EdgeInsets.all(10.0),
              child: Column(
                // Replace with a Row for horizontal icon + text
                children: <Widget>[
                  //Image.asset('images/img_intern1a1.png'),
                  Text("Finalize")
                ],
              ),
            ),
          ],
        )),
    PageViewModel(
        decoration: const PageDecoration(
            pageColor: Color.fromARGB(255, 34, 34, 34),
            titleTextStyle: TextStyle(
              fontSize: 25.0,
              fontWeight: FontWeight.bold,
            )),
        title: 'How much experience?',
        body: 'How proficient would you say you are with these languages?',
        footer: Column(children: [
          SizedBox(
            height: 600,
            width: 600,
            child: Slider_MyApp(),
          ),
          SizedBox(
            height: 20,
          ),
          FlatButton(
            minWidth: 300.0,
            height: 70.0,
            onPressed: () => {},
            color: Colors.red,
            padding: EdgeInsets.all(10.0),
            child: Column(
              // Replace with a Row for horizontal icon + text
              children: <Widget>[
                //Image.asset('images/img_intern1a1.png'),
                Text("Finalize")
              ],
            ),
          ),
        ])),
    PageViewModel(
        decoration: const PageDecoration(
            pageColor: Color.fromARGB(255, 34, 34, 34),
            titleTextStyle: TextStyle(
              fontSize: 25.0,
              fontWeight: FontWeight.bold,
            )),
        title: 'All done!',
        body: 'Thank you for taking the time to set up your account!'
            'You can now browse interns, or add your internship listing so we can begin finding interns just for you!',
        footer: SizedBox(
            height: 800,
            width: 400,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  FlatButton(
                    minWidth: 300.0,
                    height: 70.0,
                    onPressed: () => {},
                    color: Colors.red,
                    padding: EdgeInsets.all(10.0),
                    child: Column(
                      // Replace with a Row for horizontal icon + text
                      children: <Widget>[
                        //Image.asset('images/img_intern1a1.png'),
                        Text("Finalize")
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  FlatButton(
                    minWidth: 300.0,
                    height: 70.0,
                    onPressed: () => {},
                    color: Colors.grey,
                    padding: EdgeInsets.all(10.0),
                    child: Column(
                      // Replace with a Row for horizontal icon + text
                      children: <Widget>[
                        //Image.asset('images/img_intern1a1.png'),
                        Text("Lets Start!")
                      ],
                    ),
                  ),
                ]))),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 34, 34, 34),
          // gradient: LinearGradient(
          //     begin: Alignment.topLeft,
          //     end: Alignment.bottomRight,
          //     colors: [
          //   Color(0xFF8A2387),
          //   Color(0xFFE94057),
          //   Color(0xFFF27121),
          // ])
        ),
        padding: const EdgeInsets.fromLTRB(12, 80, 12, 12),
        child: IntroductionScreen(
          //color: Colors.black,
          pages: pages,
          dotsDecorator: const DotsDecorator(
            size: Size(15, 15),
            color: Colors.blue,
            activeSize: Size.square(20),
            activeColor: Colors.red,
          ),
          showDoneButton: true,
          done: const Text(
            'Done',
            style: TextStyle(fontSize: 20),
          ),
          showSkipButton: true,
          skip: const Text(
            'Skip',
            style: TextStyle(fontSize: 20),
          ),
          showNextButton: true,
          next: const Icon(
            Icons.arrow_forward,
            size: 25,
          ),
          onDone: () => onDone(context),
          curve: Curves.bounceOut,
        ),
      ),
    ));
  }

  void onDone(context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('ON_BOARDING', false);
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => Nav()));
  }
}
