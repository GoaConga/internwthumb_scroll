import 'package:flutter/material.dart';

void main() {
  runApp(const Slider_MyApp());
}

class Slider_MyApp extends StatelessWidget {
  const Slider_MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const Slider_bar(title: 'Flutter Demo Home Page'),
    );
  }
}

class Slider_bar extends StatefulWidget {
  const Slider_bar({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<Slider_bar> createState() => _Slider_bar();
}

class _Slider_bar extends State<Slider_bar> {
  double _currentValue01 = 0;
  double _currentValue02 = 0;
  double _currentValue03 = 0;
  double _currentValue04 = 0;
  double _currentValue05 = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body:
            Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
      Text(
        'C',
        style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
      ),
      SizedBox(
        height: 20,
      ),
      Slider(
        value: _currentValue01,
        min: 0,
        max: 10,
        divisions: 4,
        label: _currentValue01.toString(),
        activeColor: Colors.red,
        thumbColor: Colors.blue,
        onChanged: (value) {
          setState(() {
            _currentValue01 = value;
          });
        },
      ),
      Text(
        'Java',
        style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
      ),
      SizedBox(
        height: 20,
      ),
      Slider(
        value: _currentValue02,
        min: 0,
        max: 10,
        divisions: 4,
        label: _currentValue02.toString(),
        activeColor: Colors.red,
        thumbColor: Colors.blue,
        onChanged: (value) {
          setState(() {
            _currentValue02 = value;
          });
        },
      ),
      Text(
        'Python',
        style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
      ),
      SizedBox(
        height: 20,
      ),
      Slider(
        value: _currentValue03,
        min: 0,
        max: 10,
        divisions: 4,
        label: _currentValue03.toString(),
        activeColor: Colors.red,
        thumbColor: Colors.blue,
        onChanged: (value) {
          setState(() {
            _currentValue03 = value;
          });
        },
      ),
      Text(
        'PHP',
        style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
      ),
      SizedBox(
        height: 20,
      ),
      Slider(
        value: _currentValue04,
        min: 0,
        max: 10,
        divisions: 4,
        label: _currentValue04.toString(),
        activeColor: Colors.red,
        thumbColor: Colors.blue,
        onChanged: (value) {
          setState(() {
            _currentValue04 = value;
          });
        },
      ),
      Text(
        'CSS',
        style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
      ),
      SizedBox(
        height: 20,
      ),
      Slider(
        value: _currentValue05,
        min: 0,
        max: 10,
        divisions: 4,
        label: _currentValue05.toString(),
        activeColor: Colors.red,
        thumbColor: Colors.blue,
        onChanged: (value) {
          setState(() {
            _currentValue05 = value;
          });
        },
      )
    ]));
  }
}
